export const HOME = '/';
export const LOGIN = '/login';
export const REGISTER = '/register';
export const WATCH = '/watch';
export const MARKETPLACE = '/marketplace';
export const GAMING = '/gaming';
export const PROFILE = '/profile';
