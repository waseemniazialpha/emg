import React from 'react';
import Routers from './routes/Router';
import './App.css';

const App: React.FC = () => {
  return <Routers />;
};

export default App;
