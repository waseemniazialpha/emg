# facebook-clone

Building Facebook Clone using React, Tailwind CSS, Node.js. GraphQL and TypeScript 🔥

<img src="https://repository-images.githubusercontent.com/295202619/a69feb00-ce17-11eb-99c0-88a325f87bf9" alt="screenshot"/>

# Installation

```javascript
cd YOUR-PROJECT-FOLDER
yarn  // install all packages dependencies
yarn start:web  // run client side
yarn start:server  // run server
```

# Contribution

Looking for contribution? Your contribution will be much appreciated. <3

Just send a PR with new changes.

Show some ❤️ by ⭐ the project.
